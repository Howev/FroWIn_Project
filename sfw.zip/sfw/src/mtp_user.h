#ifndef MTP_USER_H_
#define MTP_USER_H_

#include "typedefs.h"

int mtp_user_init(uint16_t port);

#endif // MTP_USER_H_

