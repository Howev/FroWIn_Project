#include "mtp_user.h"

int mtp_user_init(uint16_t port)
{
    return 0;
}

