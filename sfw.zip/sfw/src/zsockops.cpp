#include "zsockops.h"

#include <stdio.h>
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include "common.h"

bool is_connected(int fd)
{
    int err = 0;
    socklen_t len = sizeof(socklen_t);

    errno = 0;
    if (getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &len) == -1)
    {
        return false;
    }
    errno = err;

    return err == 0;
}

bool set_block(int fd)
{
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags == -1)
    {
        return false;

    }

    if (fcntl(fd, F_SETFL, flags & ~O_NONBLOCK) == -1)
    {
        return false;
    }

    return true;
}

bool set_nonblock(int fd)
{
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags == -1)
    {
        return false;
    }

    if (fcntl(fd, F_SETFL, flags | O_NONBLOCK) == -1)
    {
        return false;
    }

    return true;
}

bool set_reuseaddr(int fd)
{
    int on = 1;
    if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) == -1)
    {   
        return false;
    }

    return true;
}

int zsock_connect(const char *ip, uint16_t port, sockaddr_in *peer, ConnectResult *result)
{
    int fd =  socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (fd == -1)
    {
        return -1;
    }

    do
    {
        if (!set_nonblock(fd))
        {
            break;
        }

        memset(peer, 0, sizeof(*peer));
        peer->sin_family = PF_INET;
        peer->sin_addr.s_addr = inet_addr(ip);
        peer->sin_port = htons(port);
        if (connect(fd, (struct sockaddr *)peer, sizeof(*peer)) == -1)
        {
            if (errno != EINPROGRESS)
            {
                break;
            }

            // 异步连接中，在读写事件触发后通过is_connected判断是否连接成功
            *result = kConnecting;
        }
        else
        {
            // connect成功
            *result = kConnected;
        }

        return fd;
    } while (0);

    close(fd);

    return -1;
}

int zsock_listen(const char *ip, uint16_t port, sockaddr_in *addr)
{
    int fd = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (fd == -1)
    {
        return -1;
    }

    do
    {
        if (!set_reuseaddr(fd))
        {
            break;
        }
        if (!set_nonblock(fd))
        {
            break;
        }

        memset(addr, 0, sizeof(*addr));
        addr->sin_family = PF_INET;
        addr->sin_port = htons(port);
        if (ip == 0 || *ip == '\0')
        {
            addr->sin_addr.s_addr = htonl(INADDR_ANY);
        }
        else
        {
            addr->sin_addr.s_addr = inet_addr(ip);
        }

        if (bind(fd, (sockaddr *)addr, sizeof(*addr)) == -1)
        {       
            break;
        }

        if (listen(fd, 4) == -1)
        {
            break;
        }

        return fd;
    } while (0);

    close(fd);

    return -1;
}

int zsock_accept(int fd, sockaddr_in *peer)
{
    socklen_t len = sizeof(*peer);
    memset(peer, 0, len);

    return accept(fd, (struct sockaddr *)peer, &len);
}

int zsock_udp(const char *ip, uint16_t port, sockaddr_in *addr)
{
    int fd = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (fd == -1)
    {
        return -1;
    }

    do
    {
        if (!set_reuseaddr(fd))
        {
            break;
        }
        if (!set_nonblock(fd))
        {
            break;
        }

        memset(addr, 0, sizeof(*addr));
        addr->sin_family = PF_INET;
        addr->sin_port = htons(port);
        if (ip == 0 || *ip == '\0')
        {
            addr->sin_addr.s_addr = htonl(INADDR_ANY);
        }
        else
        {
            addr->sin_addr.s_addr = inet_addr(ip);
        }

        if (bind(fd, (sockaddr *)addr, sizeof(*addr)) == -1)
        {       
            break;
        }

        return fd;
    } while (0);

    close(fd);

    return -1;
}

void zsock_setaddr(const char *addrstr, sockaddr_in *addr)
{
    char ip[16] = { 0 };
    uint16_t port;

    if (splitaddr(addrstr, ip, &port))
    {
        zsock_setaddr(ip, port, addr);
    }

}

void zsock_setaddr(const char *ip, uint16_t port, sockaddr_in *addr)
{
    memset(addr, 0, sizeof(*addr));
    addr->sin_family = PF_INET;
    addr->sin_port = htons(port);
    if (ip == 0 || *ip == '\0')
    {
        addr->sin_addr.s_addr = htonl(INADDR_ANY);
    }
    else
    {
        addr->sin_addr.s_addr = inet_addr(ip);
    }
}

