#ifndef COMMON_H_
#define COMMON_H_

#include "typedefs.h"

//struct timeval;

//string hex2str(const uchar *buf, size_t cnt, bool neat);
//void str2hex(const uchar *buf, size_t length, ByteArray &hex);
//// 跳过空的参数
//void tokenize(const string &str, Vstring &tokens, const string &delimiters);
//// 不跳过空的参数
//void tokenizeEx(const string &str, Vstring &tokens, const string &delimiters);
// 计算begin和end时间间隔,单位毫秒
//double timediff(const timeval &begin, const timeval &end);
//int timediff(time_t begin, time_t end);
bool splitaddr(const char *addr, char *ip, uint16_t *port);
//int convert(const char *from, const char *to, char* save, int savelen, const char *src, int srclen);

#endif // COMMON_H_

