#ifndef TYPEDEFS_H_
#define TYPEDEFS_H_

#include <stdint.h>

//enum { ZLOG_STDOUT = 1, ZLOG_FILE = 2, ZLOG_SYSLOG = 4 };
//enum { ZLOG_DAY = 1, ZLOG_HOUR = 2 };
//
struct Timestamp
{
    uint32_t usec;
    uint32_t sec;
};

struct Payload
{
    uint16_t  type;
    struct Timestamp timestamp;
    uint8_t   e1;
    uint8_t   ts;
    uint8_t   start_ts;
    uint16_t  seq;
    uint8_t   data[];
};

#endif // TYPEDEFS_H_

