/*
 * version.c
 * Automatically generated
 */

#include "libss7.h"

static const char ss7_version[] = "2.0.0";

const char *ss7_get_version(void)
{
	return ss7_version;
}

