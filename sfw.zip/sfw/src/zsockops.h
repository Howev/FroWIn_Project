#ifndef ZSOCKOPS_H_
#define ZSOCKOPS_H_

#include <stdint.h>

struct sockaddr_in;

enum ConnectResult { kConnecting, kConnected };

// 检查非阻塞连接是否成功
bool is_connected(int fd);
bool set_block(int fd);
bool set_nonblock(int fd);
bool set_reuseaddr(int fd);

// 创建非阻塞连接
// 成功返回socket fd，result标记连接是否完成
// 失败返回-1
int zsock_connect(const char *ip, uint16_t port, sockaddr_in *peer, ConnectResult *result);

int zsock_listen(const char *ip, uint16_t port, sockaddr_in *addr);
int zsock_accept(int fd, sockaddr_in *peer);
int zsock_udp(const char *ip, uint16_t port, sockaddr_in *addr);

void zsock_setaddr(const char *addrstr, sockaddr_in *addr);
void zsock_setaddr(const char *ip, uint16_t port, sockaddr_in *addr);

#endif // ZSOCKOPS_H_

